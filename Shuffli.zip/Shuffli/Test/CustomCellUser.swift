//
//  CustomCellUser.swift
//  Test
//
//  Created by Jessica Vilaysak on 10/5/17.
//  Copyright © 2017 Pranav Joshi. All rights reserved.
//

import UIKit

class CustomCellUser: UICollectionViewCell {
    
 
    @IBOutlet var fld_username: UILabel!
    
    @IBOutlet var deleteUser: UIImageView!
    
    
}
